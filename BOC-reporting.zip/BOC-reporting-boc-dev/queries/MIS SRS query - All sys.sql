select * from onesumx.dbo.v_srs_boc_alldates_allsys
where date='2024-09-30'
and entity='106'
and SOURCE_SYSTEM not in ('777')